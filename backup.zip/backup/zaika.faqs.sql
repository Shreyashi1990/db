/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `faqs` VALUES
(1,"Dashwood marianne in of entrance be on wondered","publish","","Not attention say frankness intention out dashwoods now curiosity. Stronger ecstatic as no judgment daughter speedily thoughts. Worse downs nor might she court did nay forth these.","2020-07-20 20:50:22","2020-07-20 20:50:22"),
(2,"Wondered sociable he carriage in speedily","publish","","Not attention say frankness intention out dashwoods now curiosity. Stronger ecstatic as no judgment daughter speedily thoughts. Worse downs nor might she court did nay forth these.","2020-07-20 20:50:27","2020-07-20 20:51:40"),
(3,"Not attention say frankness intention out dashwoods","publish","","Not attention say frankness intention out dashwoods now curiosity. Stronger ecstatic as no judgment daughter speedily thoughts. Worse downs nor might she court did nay forth these.","2020-07-20 20:50:30","2020-07-20 20:52:14"),
(4,"Stronger ecstatic as no judgment daughter speedily","publish","","Not attention say frankness intention out dashwoods now curiosity. Stronger ecstatic as no judgment daughter speedily thoughts. Worse downs nor might she court did nay forth these.","2020-07-20 20:52:18","2020-07-20 20:52:41"),
(5,"Worse downs nor might she court did nay forth","publish","","Not attention say frankness intention out dashwoods now curiosity. Stronger ecstatic as no judgment daughter speedily thoughts. Worse downs nor might she court did nay forth these.","2020-07-20 20:52:22","2021-06-17 15:03:03");
