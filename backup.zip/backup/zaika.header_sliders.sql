/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `header_sliders` VALUES
(1,"Summer","collection 02","Woman\'s Collection","on","Shop Now","#","205","2020-05-31 04:20:26","2021-09-19 05:47:06"),
(5,"Summer","collection 01","Women\'s Dress Store","on","Shop Now","#","204","2020-05-31 04:24:40","2021-09-19 03:47:40"),
(6,"Summer","collection 03","Woman\'s Collection","on","Shop Now","0","207","2021-09-19 05:50:55","2021-09-19 05:50:55");
