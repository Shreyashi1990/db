/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `blog_categories` VALUES
(1,"Startup Business","publish","2020-06-09 02:29:04","2020-06-09 02:29:04"),
(2,"Ecommerce","publish","2020-06-09 02:29:20","2020-06-09 02:29:20"),
(3,"Digital Marketing","publish","2020-06-09 02:29:27","2020-06-09 02:29:27");
