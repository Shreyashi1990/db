/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `product_additional_information` VALUES
(346,38,"Cloth Type","Cotton Mix",NULL,NULL),
(347,38,"Color","Navy Blue",NULL,NULL),
(348,39,"Cloth Type","Wool",NULL,NULL),
(355,21,"Total Item","22",NULL,NULL),
(356,21,"Total Quantity","5 KG",NULL,NULL),
(357,21,"Expires At","31 October 2021",NULL,NULL),
(358,25,"Total Item","9",NULL,NULL),
(359,25,"Expires At","31 October 2021",NULL,NULL),
(360,26,"Total Item","9",NULL,NULL),
(361,26,"Expires At","31 October 2021",NULL,NULL),
(362,33,"Multiple Color Available","Yes",NULL,NULL),
(363,33,"Available Colors","Green, Cyan, Blue",NULL,NULL),
(364,33,"Available Sizes","S, M, L,  XL, XXL",NULL,NULL),
(365,37,"Cloth Type","Pure Cotton",NULL,NULL),
(366,37,"Sleeve","Full Sleeve",NULL,NULL),
(367,37,"Collar Type","Tab, Cutaway",NULL,NULL),
(370,36,"Cloth Type","Cotton Mix",NULL,NULL),
(371,36,"Sleeve","Full Sleeve",NULL,NULL);
