/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `social_icons` VALUES
(1,"lab la-twitter","https://twitter.com/xgenious1","2020-06-19 23:55:51","2020-06-20 00:09:12"),
(2,"lab la-facebook-f","https://www.facebook.com/xgenious","2020-06-19 23:56:17","2021-02-27 13:28:11"),
(3,"lab la-accessible-icon","lorem","2020-06-20 00:10:18","2021-11-21 00:54:23"),
(4,"lab la-instagram","#","2020-06-20 00:10:35","2020-06-20 00:10:35");
