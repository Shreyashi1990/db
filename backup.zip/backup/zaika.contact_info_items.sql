/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `contact_info_items` VALUES
(1,"Email Address","lar la-envelope","info@sohan.xgenious.com","2020-07-20 16:45:32","2021-07-07 12:31:12"),
(2,"Phone","las la-phone","+123 444 5555\r\n+32413432432","2020-07-20 16:46:20","2020-07-20 16:48:57"),
(3,"Open Hours","lar la-clock","Sat - Wed\r\n10AM - 7PM","2020-07-20 16:49:53","2020-07-20 16:49:53"),
(4,"Location","las la-map-marker-alt","2626 Angie Drive\r\nSanta Ana","2020-07-20 16:51:00","2020-07-20 16:51:17");
