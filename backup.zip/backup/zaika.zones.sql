/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `zones` VALUES
(1,"Southeast Asia","2021-10-07 03:56:21","2021-10-07 03:56:21"),
(2,"Australia and Oceania","2021-10-08 23:00:53","2021-10-08 23:00:53"),
(3,"Western Europe","2021-11-25 03:53:37","2021-11-25 03:53:37"),
(4,"North America","2021-11-25 03:54:39","2021-11-25 03:54:39");
