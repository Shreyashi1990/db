/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `campaigns` VALUES
(22,"Eid Sale","Eid Sale 2022",737,"publish","2022-01-05 09:59:10","2022-04-13 07:08:08"),
(35,"New Year Sale","New year Sale 2022",716,"publish","2022-01-05 09:59:10","2022-04-13 07:08:37");
