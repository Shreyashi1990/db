/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `form_builders` VALUES
(1,"Contact Form","admin@mail.com","Submit","{\"success_message\":\"Success\",\"field_type\":[\"text\",\"email\",\"text\",\"textarea\"],\"field_name\":[\"your-name\",\"your-mail\",\"your-subject\",\"your-message\"],\"field_placeholder\":[\"Your Name\",\"Your Email\",\"Your Subject\",\"Your Message\"],\"field_required\":[\"on\",\"on\"]}","Success","2021-10-20 00:41:50","2021-11-29 02:00:36"),
(2,"FAQ Form","admin@email.com","Submit","{\"success_message\":\"Your question has been submitted\",\"field_type\":[\"text\",\"email\",\"textarea\"],\"field_name\":[\"name\",\"email\",\"message\"],\"field_placeholder\":[\"Your Name\",\"Your Email\",\"Your Message\"],\"field_required\":[\"on\"]}","Your question has been submitted","2021-10-26 23:12:38","2021-10-26 23:15:45");
