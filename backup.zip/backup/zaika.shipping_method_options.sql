/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `shipping_method_options` VALUES
(6,"Flat Rates",1,1,1,"none",9.00,0.00,NULL,"2021-10-08 23:03:27","2021-10-08 23:03:27"),
(8,"Free Shipping",3,1,0,"none",0.00,0.00,NULL,"2021-10-08 23:12:38","2021-10-08 23:12:38"),
(9,"North America",4,1,1,"min_order_or_coupon",10.00,50.00,"North22","2022-01-22 12:47:05","2022-01-22 12:47:05"),
(11,"North America AndShip",5,1,1,"min_order_and_coupon",10.00,50.00,"NorthAnd","2022-01-22 12:50:18","2022-01-22 12:50:18");
