/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `admins` VALUES
(27,"SuperAdmin","super_admin","cloudboard.live@gmail.com",1,"1",NULL,"$2y$10$DE2t1AtWroFCEwjKUTBg2uL0coJB/XjFGVFXs8cDjwyeYRxdPIjQS","eDu8dDidb49ACDBLCyd1JvtGUkcFiF6E2NSLwqmvxdpv2ES3D0zV7XBbuppt","2023-02-25 06:03:28","2023-02-25 06:03:28");
