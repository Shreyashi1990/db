/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `product_attributes` VALUES
(1,"Color","[\"Red\",\"Green\",\"Blue\",\"Cyan\"]","2021-09-21 04:18:49","2021-09-21 04:28:24"),
(2,"Size","[\"S\",\"M\",\"L\",\"XL\",\"XXL\"]","2021-09-21 04:29:17","2021-09-21 04:29:40");
