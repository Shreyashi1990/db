/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `support_departments` VALUES
(1,"Product Delivery","publish","2021-11-09 07:06:14","2021-11-09 07:06:40"),
(2,"Product Coupon","publish","2021-11-09 07:06:27","2021-11-09 07:06:32");
