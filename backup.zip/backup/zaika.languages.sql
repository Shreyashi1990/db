/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `languages` VALUES
(1,"English (UK)","en_GB","ltr","publish",1,"2021-06-26 20:31:44","2022-04-03 01:53:36"),
(3,"العربية","ar","rtl","publish",0,"2021-11-20 06:57:11","2022-04-03 01:53:19");
