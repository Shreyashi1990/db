/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `shipping_methods` VALUES
(1,"Flat Rates",2,0,"2021-10-08 23:01:35","2021-11-30 17:10:53"),
(3,"Free Shipping",1,1,"2021-10-08 23:12:38","2022-03-20 04:05:28"),
(4,"North America",4,0,"2022-01-22 12:47:05","2022-03-20 04:05:28"),
(5,"North America AndShip",4,0,"2022-01-22 12:49:10","2022-01-22 12:50:18");
