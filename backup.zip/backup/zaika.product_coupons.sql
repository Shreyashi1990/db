/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `product_coupons` VALUES
(1,"January Sale","Jan22","10","percentage","all","","2022-01-31","publish","2021-11-01 06:48:02","2022-01-27 16:39:21");
