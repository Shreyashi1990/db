/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `model_has_roles` VALUES
(3,"App\\Admin",1),
(2,"App\\Admin",3),
(3,"App\\Admin",4),
(3,"App\\Admin",5),
(2,"App\\Admin",6),
(3,"App\\Admin",7),
(3,"App\\Admin",17),
(3,"App\\Admin",24),
(3,"App\\Admin",25),
(3,"App\\Admin",27);
